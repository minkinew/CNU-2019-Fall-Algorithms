package HuffmanCode;

import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        Huffman.encoding("data12.txt", "hw12_06_201502023_table.txt", "hw12_06_201502023_encoded.txt");
        Huffman.decoding("data12_table.txt", "data12_encoded.txt", "hw12_06_201502023_decoded.txt");
    }
}